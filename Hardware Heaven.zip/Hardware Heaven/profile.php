<?php
    session_start();
    if(!isset($_SESSION['uid'])){
        header('location:index.php');
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hardware Heaven</title>

    <!-- Mobile Specific Metas-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- Bootstrap-->
    <link rel="stylesheet" href="stylesheet/bootstrap.css">

    <!-- Template Style-->
    <link rel="stylesheet" href="stylesheet/all.css">
    <link rel="stylesheet" href="stylesheet/animate.css">
    <link rel="stylesheet" href="stylesheet/style.css">
    <link rel="stylesheet" href="stylesheet/shortcodes.css">
    <link rel="stylesheet" href="stylesheet/mobile-menu.css">
    <link rel="stylesheet" href="stylesheet/responsive.css">
    <link rel="stylesheet" href="stylesheet/jquery-ui.css">
    <link rel="stylesheet" href="stylesheet/flexslider.css">
    <link rel="stylesheet" href="stylesheet/owl.theme.default.min.css">
    <link rel="stylesheet" href="stylesheet/owl.carousel.min.css">
    <link rel="stylesheet" href="rev-slider/css/layers.css">
    <link rel="stylesheet" href="rev-slider/css/navigation.css">
    <link rel="stylesheet" href="rev-slider/css/settings.css">
    <link rel="stylesheet" href="stylesheet/jquery-fancybox.css">

    <link href="images/hh.ico" rel="shortcut icon">
</head>

<body>
 <div class="bg-bordcuct-1">
        <header id="header" class="header widget-header header-type1 cl-bl">
            <div class="nav">
                <div class="header-wrap d-flex">
                    <div id="logo" class="logo d-flex align-items-center logo-customize-bg">
                        <a href="home.html" title="Hardware Heaven"><img src="images/logo/03.png" data-width="150" data-height="75" alt="images" data-retina="images/logo1.png"></a>
                    </div>
                    <div class="header-content d-flex flex-grow-1 align-items-center flex-row justify-content-lg-start justify-content-end">
                        <div class="icon-header-wrap-left d-flex justify-content-center">
                            <div class="wrap-language cl-bl">
                                <div class="language-name language-current">ENGLISH</div>
                                <div class="list-flat-chooser">
                                    <ul class="select-name">
                                        <li><a href="#">BANGLA</a></li>
                                    </ul>
                                </div>
                            </div>
							
                        </div>
						
                        <div class="nav-wrap d-flex justify-content-start">
						
                            <nav id="main-nav" class="main-nav" role="navigation">
							
                                <ul id="menu-main-menu" class="d-flex menu justify-content-start">
								
                                    <li class="menu-item"><a href="index.php">HOME</a></li>
									
                                    <li class="menu-item"><a href="products.html">PRODUCTS</a></li>
									
									
									
									
									
									<li class="menu-item"><a href="cart.html">CART</a></li>
									
                                    
									<li class="menu-item menu-item-has-children"><a href="#"><?php echo "Hi,".$_SESSION["name"]; ?></a>
                                        <ul class="sub-menu">
										    <li class="menu-item"><a href="checkout.html">CHECKOUT</a></li>
                                            <li class="menu-item"><a href="logout.php">LOGOUT</a></li>
                                            <li class="menu-item"><a href="contact-us.html">CONTACT US</a></li>
                                        </ul>  
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="icon-header-wrap-right d-flex justify-content-end">
                            <div class="header-item-wrap d-flex justify-content-end">
                                <div class="indicator indicator-trigger-click">
                                    <a class="icon icon-header-search indicator_button" href="#"><i class="fal fa-search"></i></a>
                                    <form action="#" class="search-header-hide">
                                        <input type="search" class="search-product" placeholder="Enter your keyword">
                                    </form>
                                </div>
                               <a class="icon icon-header-user" href="profile.html"><i class="fal fa-user-alt"></i></a>
                                
                                <div class="indicator indicator-trigger-click">
                                    <a class="icon icon-header-bag indicator_button" href="#"><i class="fal fa-shopping-bag"></i>
                                        <span class="count-cart cl-bl">2</span>
                                    </a>
                                    <div class="mini-cart">
                                        <div class="mini-cart-wrap">
                                            <ul>
                                                <li class="item d-flex">
                                                    <div class="thumnail">
                                                        <img src="images/shop/01.png" alt="images">
                                                    </div>
                                                    <div class="summary">
                                                        <p>Furniture</p>
                                                        <a href="#" class="item-name">Stool - solid</a>
                                                        <div class="item-price">$999</div>
                                                    </div>
                                                </li>
                                                <li class="item d-flex">
                                                    <div class="thumnail">
                                                        <img src="images/shop/02.png" alt="images">
                                                    </div>
                                                    <div class="summary">
                                                        <p>Furniture</p>
                                                        <a href="#" class="item-name">Lorem Ipsum</a> 
                                                        <div class="item-price">$999</div>
                                                    </div>
                                                </li>
                                            </ul>
                                            <div class="mini-cart-total text-right">
                                                <p>
                                                    <span>SUB TOTAL:</span>
                                                    <span class="total">$1810.00</span>
                                                </p>
                                                <p>
                                                    <span>TOTAL:</span>
                                                    <span class="total">$1810.00</span>
                                                </p>
                                            </div>
                                            <div class="mini-cart-buttons">
                                                <a href="cart.html" class="btn-view-cart hv-bounce-bl">VIEW CART</a>
                                                <a href="checkout.html" class="btn-checkout hv-bounce-bl">CHECKOUT</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </div>
        </header><!-- header -->
        <div class="page-title">
            <div class="page-title-inner">
                <div class="breadcrumbs text-left">
                   
                </div>
            </div>
        </div>
    </div><!-- bg-bordcuct -->
   
    <div class="flat-row-half">

        <div class="related-product">
            <div class="container">
                <div class="title-section">
                    <div class="flat-title less text-center">OUR PRODUCTS</div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-6 col-6 col-fl2">
                        <div class="item-product item-product-grid cl-bl">
                            <div class="featured-post">
                                <div class="entry-image">
                                    <img src="images/shop/01.png" alt="images">
                                    <span class="new">New</span>
                                </div>
                            </div>
                            <div class="content-product">
                                <div class="btn-add"><i class="fal fa-plus"></i></div>
                                <div class="info-product">
                                    <div class="text">
                                        <p class="gen-fasion">Men fasion</p>
                                        <p class="item-kind">Dress</p>
                                    </div>
                                    <span class="price">$590</span>
                                </div>
                                <div class="title">
                                    <a href="#">Straight Jeans Topshop</a>
                                </div>
                                <div class="add-to-cart">
                                    <a href="#" class="hv-bounce-bk">+ ADD TO CART</a>
                                    <span class="favorite"><i class="fal fa-heart"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-6 col-fl2">
                        <div class="item-product item-product-grid cl-bl">
                            <div class="featured-post">
                                <div class="entry-image">
                                    <img src="images/shop/02.png" alt="images">
                                    <span class="on-sale">Sale</span>
                                </div>
                            </div>
                            <div class="content-product">
                                <div class="btn-add"><i class="fal fa-plus"></i></div>
                                <div class="info-product">
                                    <div class="text">
                                        <p class="gen-fasion">Men fasion</p>
                                        <p class="item-kind">Bag</p>
                                    </div>
                                    <span class="price">$660</span>
                                </div>
                                <div class="title">
                                    <a href="#">Eddie Bauer Backpack</a>
                                </div>
                                <div class="add-to-cart">
                                    <a href="#" class="hv-bounce-bk">+ ADD TO CART</a>
                                    <span class="favorite"><i class="fal fa-heart"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-6 col-fl2">
                        <div class="item-product item-product-grid cl-bl">
                            <div class="featured-post">
                                <div class="entry-image">
                                    <img src="images/shop/03.png" alt="images">
                                    <span class="on-sale">-10%</span>
                                </div>
                            </div>
                            <div class="content-product">
                                <div class="btn-add"><i class="fal fa-plus"></i></div>
                                <div class="info-product">
                                    <div class="text">
                                        <p class="gen-fasion">Women fasion</p>
                                        <p class="item-kind">Dress</p>
                                    </div>
                                    <span class="price">$250</span>
                                </div>
                                <div class="title">
                                    <a href="#">Long Sleeve Stripe</a>
                                </div>
                                <div class="add-to-cart">
                                    <a href="#" class="hv-bounce-bk">+ ADD TO CART</a>
                                    <span class="favorite"><i class="fal fa-heart"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-6 col-fl2">
                        <div class="item-product item-product-grid cl-bl">
                            <div class="featured-post">
                                <div class="entry-image">
                                    <img src="images/shop/04.png" alt="images">
                                </div>
                            </div>
                            <div class="content-product">
                                <div class="btn-add"><i class="fal fa-plus"></i></div>
                                <div class="info-product">
                                    <div class="text">
                                        <p class="gen-fasion">Men fasion</p>
                                        <p class="item-kind">Watch</p>
                                    </div>
                                    <span class="price">$460</span>
                                </div>
                                <div class="title">
                                    <a href="#">Auto Hamilton Watch</a>
                                </div>
                                <div class="add-to-cart">
                                    <a href="#" class="hv-bounce-bk">+ ADD TO CART</a>
                                    <span class="favorite"><i class="fal fa-heart"></i></span>
                                </div>
                            </div>
							
							
                        </div>
                    </div>
					
					  <div class="col-lg-3 col-md-4 col-sm-6 col-6 col-fl2">
                        <div class="item-product item-product-grid cl-bl">
                            <div class="featured-post">
                                <div class="entry-image">
                                    <img src="images/shop/05.png" alt="images">
                                </div>
                            </div>
                            <div class="content-product">
                                <div class="btn-add"><i class="fal fa-plus"></i></div>
                                <div class="info-product">
                                    <div class="text">
                                        <p class="gen-fasion">Men fasion</p>
                                        <p class="item-kind">Watch</p>
                                    </div>
                                    <span class="price">$460</span>
                                </div>
                                <div class="title">
                                    <a href="#">Auto Hamilton Watch</a>
                                </div>
                                <div class="add-to-cart">
                                    <a href="#" class="hv-bounce-bk">+ ADD TO CART</a>
                                    <span class="favorite"><i class="fal fa-heart"></i></span>
                                </div>
                            </div>
							
							
                        </div>
                    </div>
					
					  <div class="col-lg-3 col-md-4 col-sm-6 col-6 col-fl2">
                        <div class="item-product item-product-grid cl-bl">
                            <div class="featured-post">
                                <div class="entry-image">
                                    <img src="images/shop/06.png" alt="images">
                                </div>
                            </div>
                            <div class="content-product">
                                <div class="btn-add"><i class="fal fa-plus"></i></div>
                                <div class="info-product">
                                    <div class="text">
                                        <p class="gen-fasion">Men fasion</p>
                                        <p class="item-kind">Watch</p>
                                    </div>
                                    <span class="price">$460</span>
                                </div>
                                <div class="title">
                                    <a href="#">Auto Hamilton Watch</a>
                                </div>
                                <div class="add-to-cart">
                                    <a href="#" class="hv-bounce-bk">+ ADD TO CART</a>
                                    <span class="favorite"><i class="fal fa-heart"></i></span>
                                </div>
                            </div>
							
							
                        </div>
                    </div>
					
					  <div class="col-lg-3 col-md-4 col-sm-6 col-6 col-fl2">
                        <div class="item-product item-product-grid cl-bl">
                            <div class="featured-post">
                                <div class="entry-image">
                                    <img src="images/shop/07.png" alt="images">
                                </div>
                            </div>
                            <div class="content-product">
                                <div class="btn-add"><i class="fal fa-plus"></i></div>
                                <div class="info-product">
                                    <div class="text">
                                        <p class="gen-fasion">Men fasion</p>
                                        <p class="item-kind">Watch</p>
                                    </div>
                                    <span class="price">$460</span>
                                </div>
                                <div class="title">
                                    <a href="#">Auto Hamilton Watch</a>
                                </div>
                                <div class="add-to-cart">
                                    <a href="#" class="hv-bounce-bk">+ ADD TO CART</a>
                                    <span class="favorite"><i class="fal fa-heart"></i></span>
                                </div>
                            </div>
							
							
                        </div>
                    </div>
					
					  <div class="col-lg-3 col-md-4 col-sm-6 col-6 col-fl2">
                        <div class="item-product item-product-grid cl-bl">
                            <div class="featured-post">
                                <div class="entry-image">
                                    <img src="images/shop/09.png" alt="images">
                                </div>
                            </div>
                            <div class="content-product">
                                <div class="btn-add"><i class="fal fa-plus"></i></div>
                                <div class="info-product">
                                    <div class="text">
                                        <p class="gen-fasion">Men fasion</p>
                                        <p class="item-kind">Watch</p>
                                    </div>
                                    <span class="price">$460</span>
                                </div>
                                <div class="title">
                                    <a href="#">Auto Hamilton Watch</a>
                                </div>
                                <div class="add-to-cart">
                                    <a href="#" class="hv-bounce-bk">+ ADD TO CART</a>
                                    <span class="favorite"><i class="fal fa-heart"></i></span>
                                </div>
                            </div>
							
							
                        </div>
                    </div>
					
					
                </div>
            </div>
        </div>
    </div><!-- flat-row-half -->
    <footer id="footer" class="footer footer-type1 footer-common-res">
        
           <div class="footer-wrap clearfix">
            <div class="logo-footer">
                <div class="img-footer">
                   <img src="images/logo2.png" alt="images">
                </div>
                <div class="copyright">
                    © Hardware Heaven 2020
                </div>
                <ul class="social-icon">
                   
                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
					<li><a href="#"><i class="fab fa-twitter"></i></a></li>
					
                </ul>
            </div>
            <div class="custom-serive widget">
                <div class="widget-title">Top Links</div>
                <ul class="widget-nav-menu">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">My Account</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Information</a></li>
                </ul>
            </div>
            <div class="information widget">
                <div class="widget-title">My Account</div>
                <ul class="widget-nav-menu">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">My Account</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Information</a></li>
                </ul>
            </div>
            <div class="our-terms widget">
                <div class="widget-title">Our Terms</div>
                <ul class="widget-nav-menu">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Information</a></li>
                </ul>
            </div>
            <div class="our-terms widget">
           
                <div class="widget-title">Payment Methods</div>
                <div class="img-payment">
                    <img src="images/payment.png" alt="images">
                </div>
           
			 </div>
        </div>
          
    </footer><!-- footer -->
    `
    
    <script src="javascript/jquery.min.js"></script>
    <script src="javascript/owl.carousel.min.js"></script>
    <script src="javascript/gmap3.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA0C5etf1GVmL_ldVAichWwFFVcDfa1y_c"></script>
    <script src="javascript/jquery-ui.js"></script>
    <script src="javascript/flex-slider.min.js"></script>
    <script src="javascript/jquery-fancybox.js"></script>
    <script src="javascript/parallax.js"></script>
    <script src="javascript/equalize.min.js"></script>
    <script src="javascript/plugins.js"></script>
    <script src="javascript/main.js"></script>

    <!-- slider -->
    <script src="rev-slider/js/jquery.themepunch.tools.min.js"></script>
    <script src="rev-slider/js/jquery.themepunch.revolution.min.js"></script>
    <script src="javascript/rev-slider.js"></script>

    <!-- Load Extensions only on Local File Systems ! The following part can be removed on Server for On Demand Loading -->
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.actions.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.carousel.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.kenburn.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.layeranimation.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.migration.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.navigation.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.parallax.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.slideanims.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.video.min.js"></script>
    
</body>
</html>