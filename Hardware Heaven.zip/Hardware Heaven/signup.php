<?php
   include "db.php";

  if(isset($_POST['submit']))

  {
    session_start();
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];
    
    

    $sql="INSERT INTO user (name,email,password,phone,address) VALUES ('$name','$email','$password','$phone','$address')";
    mysqli_query($conn,$sql);

    $_SESSION['name']=$name;
    $_SESSION['email']=$email;
    $_SESSION['password']=$password;
    $_SESSION['phone']=$phone;
    $_SESSION['address']=$address;
    
    header("location: login.php");
  }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hardware Heaven</title>

    <!-- Mobile Specific Metas-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- Bootstrap-->
    <link rel="stylesheet" href="stylesheet/bootstrap.css">

    <!-- Template Style-->
    <link rel="stylesheet" href="stylesheet/all.css">
    <link rel="stylesheet" href="stylesheet/animate.css">
    <link rel="stylesheet" href="stylesheet/style.css">
    <link rel="stylesheet" href="stylesheet/shortcodes.css">
    <link rel="stylesheet" href="stylesheet/mobile-menu.css">
    <link rel="stylesheet" href="stylesheet/responsive.css">
    <link rel="stylesheet" href="stylesheet/jquery-ui.css">
    <link rel="stylesheet" href="stylesheet/flexslider.css">
    <link rel="stylesheet" href="stylesheet/owl.theme.default.min.css">
    <link rel="stylesheet" href="stylesheet/owl.carousel.min.css">
    <link rel="stylesheet" href="rev-slider/css/layers.css">
    <link rel="stylesheet" href="rev-slider/css/navigation.css">
    <link rel="stylesheet" href="rev-slider/css/settings.css">
    <link rel="stylesheet" href="stylesheet/jquery-fancybox.css">

    <link href="images/hh.ico" rel="shortcut icon">
</head>

<body>
 <div class="bg-bordcuct-1">
        <header id="header" class="header widget-header header-type1 cl-bl">
            <div class="nav">
                <div class="header-wrap d-flex">
                    <div id="logo" class="logo d-flex align-items-center logo-customize-bg">
                        <a href="home.html" title="Hardware Heaven"><img src="images/logo/03.png" data-width="150" data-height="75" alt="images" data-retina="images/logo1.png"></a>
                    </div>
                    <div class="header-content d-flex flex-grow-1 align-items-center flex-row justify-content-lg-start justify-content-end">
                        <div class="icon-header-wrap-left d-flex justify-content-center">
                            <div class="wrap-language cl-bl">
                                <div class="language-name language-current">ENGLISH</div>
                                <div class="list-flat-chooser">
                                    <ul class="select-name">
                                        <li><a href="#">BANGLA</a></li>
                                    </ul>
                                </div>
                            </div>
							
                        </div>
						
                        <div class="nav-wrap d-flex justify-content-start">
						
                            <nav id="main-nav" class="main-nav" role="navigation">
							
                                <ul id="menu-main-menu" class="d-flex menu justify-content-start">
								
                                    <li class="menu-item"><a href="index.php">HOME</a></li>
									
                                    <li class="menu-item"><a href="products.html">PRODUCTS</a></li>
									
									<li class="menu-item"><a href="login.php">LOGIN</a></li>
									
									<li class="menu-item"><a href="signup.php">SIGNUP</a></li>
									
									<li class="menu-item"><a href="cart.html">CART</a></li>
									
                                    
									<li class="menu-item menu-item-has-children">More+</a>
                                        <ul class="sub-menu">
										    <li class="menu-item"><a href="checkout.html">CHECKOUT</a></li>
                                            <li class="menu-item"><a href="login.html">LOGOUT</a></li>
											
                                            <li class="menu-item"><a href="contact-us.html">CONTACT US</a></li>
                                        </ul>  
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="icon-header-wrap-right d-flex justify-content-end">
                            <div class="header-item-wrap d-flex justify-content-end">
                                <div class="indicator indicator-trigger-click">
                                    <a class="icon icon-header-search indicator_button" href="#"><i class="fal fa-search"></i></a>
                                    <form action="#" class="search-header-hide">
                                        <input type="search" class="search-product" placeholder="Enter your keyword">
                                    </form>
                                </div>
                               <a class="icon icon-header-user" href="profile.html"><i class="fal fa-user-alt"></i></a>
                                
                                <div class="indicator indicator-trigger-click">
                                    <a class="icon icon-header-bag indicator_button" href="#"><i class="fal fa-shopping-bag"></i>
                                        <span class="count-cart cl-bl">2</span>
                                    </a>
                                      <div class="mini-cart">
                                        <div class="mini-cart-wrap">
                                            <ul>
                                                <li class="item d-flex">
                                                    <div class="thumnail">
                                                        <img src="images/shop/01.png" alt="images">
                                                    </div>
                                                    <div class="summary">
                                                        <p>Phone</p>
                                                        <a href="#" class="item-name">iphone</a>
                                                        <div class="item-price">90000 BDT</div>
                                                    </div>
                                                </li>
                                                <li class="item d-flex">
                                                    <div class="thumnail">
                                                        <img src="images/shop/02.png" alt="images">
                                                    </div>
                                                    <div class="summary">
                                                        <p>Phone</p>
                                                        <a href="#" class="item-name">iphone</a> 
                                                        <div class="item-price">90000 BDT</div>
                                                    </div>
                                                </li>
                                            </ul>
                                            <div class="mini-cart-total text-right">
                                                <p>
                                                    <span>SUB TOTAL:</span>
                                                    <span class="total">106000 BDT</span>
                                                </p>
                                                <p>
                                                    <span>TOTAL:</span>
                                                    <span class="total">106000 BDT</span>
                                                </p>
                                            </div>
                                            <div class="mini-cart-buttons">
                                                <a href="cart.html" class="btn-view-cart hv-bounce-bl">VIEW CART</a>
                                                <a href="checkout.html" class="btn-checkout hv-bounce-bl">CHECKOUT</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </div>
        </header><!-- header -->
        <div class="page-title">
            <div class="page-title-inner">
                <div class="breadcrumbs text-left">
                   
                </div>
            </div>
        </div>
    </div><!-- bg-bordcuct -->
   
    <div class="flat-row">
        <div class="container">
            <div class="d-md-flex justify-content-center">
               
                <div class="register">
                    <form action="signup.php" id="signup" method="POST" class="border-lg" onsubmit="return validateForm()">
                        <input type="text" id="name" name="name" placeholder="Full name">
                        <input type="text" id="email" name="email" placeholder="Enter your email">
                        <input type="text" id="password" name="password" placeholder="Enter your Password">
                        <input type="text" id="phone" name="phone" placeholder="(+880) 0000000000">
                        <textarea name="address" id="address" cols="30" rows="10" placeholder="Enter Your address here"></textarea>
                        <div class="or">
                            <span>OR</span>
                        </div>
                        <ul class="social-list">
                            <li>
                                <a href="#" class="login-fb"><i class="fab fa-facebook-f"></i>Facebook</a>
                            </li>
                            <li>
                                <a href="#" class="login-gg"><i class="fab fa-google"></i>Google</a>
                            </li>
                        </ul>
                        <div class="flat-button">
                        <button type="submit" name="submit" class="btn btn-danger">Signup</button>
                            <a class="btn btn-success"  href= "login.html" role="button">Login</a>	

							
                        </div>
                        <div class="row">
                            <div class="col-6 d-flex align-items-center">
                                <div class="checkbox-none">
                                    <input class="inp-checkbox" id="cbx1" type="checkbox">
                                    <label class="custom-checkbox" for="cbx1">
                                        <span>
                                            <svg width="8px" height="6px" viewbox="0 0 12 10">
                                                <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
                                            </svg>
                                        </span>
                                        <span>Remember Me</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-6 text-right text-password">
                                <p>Forgot <a href="#">password?</a></p>
                            </div>
                        </div>
                        <script>
                            document.getElementById('signup').addEventListener('submit',submit);

                            function submit(pd)
                            {
                            pd.preventdefault();
                            var name =document.getElementById('name').value;
                            var email =document.getElementById('email').value;
                            var password =document.getElementById('password').value;
                            var phone =document.getElementById('phone').value;
                            var address =document.getElementById('address').value;
                            
                            

                            var sn="name="+name;
                            var se="email="+email;
                            var pass="password="+password
                            var sp="phone="+phone;
                            var sa="address="+address;
                            
                            

                            var req =new XMLHttpRequest();
                            req.open('POST','signup.php',true);
                            req.setRequestHeader('content-type','application/x-www-form-urlencoded');
                            req.onload =function (){

                            }
                            req.send(sn,se,pass,sp,sa);
                            }

                            function validateForm() {
                var a = document.forms["signup"]["name"].value;
                var b = document.forms["signup"]["email"].value;
                var c = document.forms["signup"]["password"].value;
                var d = document.forms["signup"]["phone"].value;
                var e = document.forms["signup"]["address"].value;
                if (a == "" || b=="" || c=="" || d=="" || e=="")
                 {
                  alert("Please fill up all the field");
                  return false;
                 }
                 
                }
                        </script>
                    </form>
                </div>
            </div>
        </div>
    </div><!-- login -->
    <footer id="footer" class="footer footer-type1 footer-common-res">
        
           <div class="footer-wrap clearfix">
            <div class="logo-footer">
                <div class="img-footer">
                   <img src="images/logo2.png" alt="images">
                </div>
                <div class="copyright">
                    © Hardware Heaven 2020
                </div>
                <ul class="social-icon">
                   
                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
					<li><a href="#"><i class="fab fa-twitter"></i></a></li>
					
                </ul>
            </div>
            <div class="custom-serive widget">
                <div class="widget-title">Top Links</div>
                <ul class="widget-nav-menu">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">My Account</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Information</a></li>
                </ul>
            </div>
            <div class="information widget">
                <div class="widget-title">My Account</div>
                <ul class="widget-nav-menu">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">My Account</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Information</a></li>
                </ul>
            </div>
            <div class="our-terms widget">
                <div class="widget-title">Our Terms</div>
                <ul class="widget-nav-menu">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Information</a></li>
                </ul>
            </div>
            <div class="our-terms widget">
           
                <div class="widget-title">Payment Methods</div>
                <div class="img-payment">
                    <img src="images/payment.png" alt="images">
                </div>
           
			 </div>
        </div>
          
    </footer><!-- footer -->
    `
    
    <script src="javascript/jquery.min.js"></script>
    <script src="javascript/owl.carousel.min.js"></script>
    <script src="javascript/gmap3.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA0C5etf1GVmL_ldVAichWwFFVcDfa1y_c"></script>
    <script src="javascript/jquery-ui.js"></script>
    <script src="javascript/flex-slider.min.js"></script>
    <script src="javascript/jquery-fancybox.js"></script>
    <script src="javascript/parallax.js"></script>
    <script src="javascript/equalize.min.js"></script>
    <script src="javascript/plugins.js"></script>
    <script src="javascript/main.js"></script>

    <!-- slider -->
    <script src="rev-slider/js/jquery.themepunch.tools.min.js"></script>
    <script src="rev-slider/js/jquery.themepunch.revolution.min.js"></script>
    <script src="javascript/rev-slider.js"></script>

    <!-- Load Extensions only on Local File Systems ! The following part can be removed on Server for On Demand Loading -->
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.actions.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.carousel.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.kenburn.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.layeranimation.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.migration.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.navigation.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.parallax.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.slideanims.min.js"></script>
    <script src="rev-slider/js/extensions/extensionsrevolution.extension.video.min.js"></script>
    
</body>
</html>